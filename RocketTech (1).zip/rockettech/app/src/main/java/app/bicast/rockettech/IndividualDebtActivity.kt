package app.bicast.rockettech

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import app.bicast.rockettech.adapter.EntryRecyAdapter
import app.bicast.rockettech.R
import app.bicast.rockettech.db.dbSql
import com.google.android.material.floatingactionbutton.FloatingActionButton

class IndividualDebtActivity : AppCompatActivity() {
    val db: dbSql = dbSql(this)
    lateinit var recyItems : RecyclerView
    var userId = 0;
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_individual_debt)

        userId = intent.getIntExtra("user_id",0)

        val fabAdd : FloatingActionButton = findViewById(R.id.fb_add)
        recyItems = findViewById(R.id.recy_peoples)
        findViewById<ImageView>(R.id.iv_toolbar_back).setOnClickListener {
            onBackPressed()
        }
        fabAdd.setOnClickListener {
            startActivity(Intent(this, EntryActivity::class.java))
        }


    }

    private fun loadItems(){
        val namesArray = db.getPersonEntries(userId)
        val adapterItems = EntryRecyAdapter(namesArray)
        recyItems.adapter = adapterItems
        recyItems.layoutManager = LinearLayoutManager(this)
    }

    override fun onResume() {
        super.onResume()
        loadItems()
    }
}