# Rocket Tech


Oferecer educação financeira acessível e de qualidade, com foco em ajudar as pessoas a gerir suas finanças pessoais de maneira mais eficiente e inteligente.
